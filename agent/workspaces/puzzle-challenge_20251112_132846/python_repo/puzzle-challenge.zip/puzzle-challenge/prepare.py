import os
import pygame as pg
import tools


SCREEN_SIZE = (1000, 600)
ORIGINAL_CAPTION = "Puzzler"

pg.mixer.pre_init(44100, -16, 1, 512)

pg.init()
os.environ['SDL_VIDEO_CENTERED'] = "TRUE"
pg.display.set_caption(ORIGINAL_CAPTION)
SCREEN = pg.display.set_mode(SCREEN_SIZE)
SCREEN_RECT = SCREEN.get_rect()
PIECE_RECT_SIZE = (80, 60)
CONTINENTS = ("Africa", "North America", "South America", "Europe", "Asia", "Oceania")

# Resolve resource paths relative to this file so imports work regardless of CWD
BASE_DIR = os.path.dirname(__file__)
GFX_DIR = os.path.join(BASE_DIR, "resources", "graphics")
SFX_DIR = os.path.join(BASE_DIR, "resources", "sounds")
MUSIC_DIR = os.path.join(BASE_DIR, "resources", "music")

GFX = tools.load_all_gfx(GFX_DIR)
SFX = tools.load_all_sfx(SFX_DIR)
MUSIC = tools.load_all_music(MUSIC_DIR)